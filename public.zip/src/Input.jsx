import React, {useState} from "react";
import './Input.css';

function Input(props){
    const colours = ["#CDABEB", "#F6CA94", "#C7CAFF", "#C1CBC0", "#F6C2F3", "#DFDA70"];
    const [note, setNote] = useState({
        title : "",
        content : ""
    });

    const [selectedColourIndex, setSelectedColourIndex] = useState(null);
   
    function updateType(event){
        const {name, value} = event.target;
        setNote((prev)=>{
         return {
           ...prev,
           [name] : value,
         }
        })
     }
    function updateColourPick(colour, index) {
        setSelectedColourIndex(index === selectedColourIndex ? null : index);
        props.colorSelect(colour);
      }

     function onsubmit(event){
        props.addNote(note);
        setNote({
            title : "",
            content : ""
        });
         event.preventDefault();
     }

    return (<div className="input-box">
        <form>
             <input onChange={updateType} type="text" name="title" placeholder="title" value={note.title}/>
            <textarea onChange={updateType} name="content" placeholder="content" value={note.content} />
            <ul>
            {colours.map((colour, index)=>{
                const isSelected = selectedColourIndex === index;
                return (
                    <li 
                    onClick={() => updateColourPick(colour, index)}
                    key={index}
                    className="colour-choice"
                    style={{backgroundColor : colour, border: isSelected ? "2px solid black" : "none"}}
                    
                     />
                );
            })}
            </ul>
            <button 
                className="submit-btn"
                onClick={onsubmit}
            >
                add
            </button>
        </form>
     </div>)
}

export default Input;