import React from "react";
import './Header.css';

function Header(){
    return <div>
        <h1 className="heading">Notes</h1>
    </div>
}

export default Header;