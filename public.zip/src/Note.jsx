import React, { useState } from "react";
import './Note.css';

function Note(props){
    function remove(){
        props.updateDelete(props.id);
    }
    return (<div className="note"
        style={{backgroundColor : props.noteColour}}
    >
        <h2>{props.title}</h2>
        <p>{props.content}</p>
        <h5>{props.noteColour}</h5>
        <button onClick={remove}>remove</button>
    </div>)
}

export default Note;